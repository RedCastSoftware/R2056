// R2056.c Version Alpha 6
// By Eddie Hudgins (RedCastSoftware)
// No headers!
int zero = 0; // Zero Flag
int inp = 0; // Input from opcode in memory (sometimes memory adress, value, etc.)
int fc = 0; // Primitive program counter
int carry = 0; // Carry flag
int A = 0; // Accumulator reg
int X = 0; // Index reg
int Y = 0; // Index reg
int SP = 0; // Stack Pointer
int P = 0; // Processor status
int len = 0; // length of program in memory
int op;
int icarus_pro[] = {
0xA9,72,0x8D,111,0xA9,101,0x8D,111,0xA9,108,0x8D,111,0xA9,108,0x8D,111,0xA9,111,0x8D,111,0xA9,32,0x8D,111,0xA9,102,0x8D,111,0xA9,114,0x8D,111,0xA9,111,0x8D,111,0xA9,109,0x8D,111,0xA9,32,0x8D,111,0xA9,116,0x8D,111,0xA9,104,0x8D,111,0xA9,101,0x8D,111,0xA9,32,0x8D,111,0xA9,77,0x8D,111,0xA9,97,0x8D,111,0xA9,99,0x8D,111,0xA9,98,0x8D,111,0xA9,111,0x8D,111,0xA9,111,0x8D,111,0xA9,107,0x8D,111,0xA9,32,0x8D,111,0xA9,78,0x8D,111,0xA9,101,0x8D,111,0xA9,111,0x8D,111,0xA9,33,0x8D,111,0xA9,32,0x8D,111,0xA9,84,0x8D,111,0xA9,104,0x8D,111,0xA9,105,0x8D,111,0xA9,115,0x8D,111,0xA9,32,0x8D,111,0xA9,105,0x8D,111,0xA9,115,0x8D,111,0xA9,32,0x8D,111,0xA9,114,0x8D,111,0xA9,117,0x8D,111,0xA9,110,0x8D,111,0xA9,110,0x8D,111,0xA9,105,0x8D,111,0xA9,110,0x8D,111,0xA9,103,0x8D,111,0xA9,32,0x8D,111,0xA9,111,0x8D,111,0xA9,110,0x8D,111,0xA9,32,0x8D,111,0xA9,97,0x8D,111,0xA9,32,0x8D,111,0xA9,54,0x8D,111,0xA9,53,0x8D,111,0xA9,48,0x8D,111,0xA9,50,0x8D,111,0xA9,32,0x8D,111,0xA9,99,0x8D,111,0xA9,112,0x8D,111,0xA9,117,0x8D,111,0xA9,32,0x8D,111,0xA9,105,0x8D,111,0xA9,110,0x8D,111,0xA9,115,0x8D,111,0xA9,105,0x8D,111,0xA9,100,0x8D,111,0xA9,101,0x8D,111,0xA9,32,0x8D,111,0xA9,111,0x8D,111,0xA9,102,0x8D,111,0xA9,32,0x8D,111,0xA9,97,0x8D,111,0xA9,32,0x8D,111,0xA9,82,0x8D,111,0xA9,49,0x8D,111,0xA9,49,0x8D,111,0xA9,32,0x8D,111,0xA9,69,0x8D,111,0xA9,109,0x8D,111,0xA9,117,0x8D,111,0xA9,108,0x8D,111,0xA9,97,0x8D,111,0xA9,116,0x8D,111,0xA9,101,0x8D,111,0xA9,100,0x8D,111,0xA9,32,0x8D,111,0xA9,67,0x8D,111,0xA9,111,0x8D,111,0xA9,109,0x8D,111,0xA9,112,0x8D,111,0xA9,117,0x8D,111,0xA9,116,0x8D,111,0xA9,101,0x8D,111,0xA9,114,0x8D,111,0xA9,33,0x8D,111,313
};
int icarus_mem[65536] = {0}; // Storable memory
int printf(const char *format, ...); // declare printf
int main() {
    for (;icarus_pro[len]!=313;len++){} // Loop through the program memory until the stop code 313 is found where the increment, len, will store the length of the program
    //printf("%d\n",len);
    while (fc < len){
	int op = icarus_pro[fc];
        switch(op) {
            case 0xA9:
                inp = icarus_pro[fc+1];
                inp%=256;
                A = inp;
                zero = (A==0);
                fc+=2;
                break;
            case 0xA2:
                inp = icarus_pro[fc+1];
                inp%=256;
                X = inp;
                zero = (X==0);
                fc+=2;
                break;
            case 0xA0:
                inp = icarus_pro[fc+1];
                inp%=256;
                Y = inp;
                zero = (Y==0);
                fc+=2;
                break;
            case 0x8D:
                inp = icarus_pro[fc+1];
                inp%=65536;
                icarus_mem[inp] = A;
                if (inp == 111) {
                    printf("%c", (char)A);
                }
                fc+=2;
                break;
            case 0x86:
                inp = icarus_pro[fc+1];
                icarus_mem[inp] = X;
                fc+=2;
                break;
            case 0x84:
                inp = icarus_pro[fc+1];
                icarus_mem[inp] = Y;
                fc+=2;
                break;
            case 0x69:
                inp = icarus_pro[fc+1];
                A+=inp+carry;
                if (A>255){
                    A%=256;
                    carry = 1;
                }
                else{
                    carry = 0;
                }
                zero = (A==0);
                fc+=2;
                break;
            case 0xE9:
                inp = icarus_pro[fc+1];
                A-=inp-(1-carry);
                if (A>255){
                    A%=256;
                    carry = 1;
                }
                else{
                    carry = 0;
                }
                zero = (A==0);
                fc+=2;
                break;
            case 0xE8:
                X++;
                if (X>255){
                    X%=256;
                    carry = 1;
                }
                else{
                    carry = 0;
                }
                zero = (X==0);
                fc++;
                break;
            case 0xC8:
                Y++;
                if (Y>255){
                    Y%=256;
                    carry = 1;
                }
                else{
                    carry = 0;
                }
                zero = (Y==0);
                fc++;
                break;
            case 0xC9:
                inp = icarus_pro[fc+1] & 0xFF;
                carry = (A>=inp);
                zero = (A==inp);
                fc+=2;
                break;
            case 0xAA:
                X = A;
                fc++;
                break;
            case 0x8A:
                A = X;
                fc++;
                break;
            case 0xA8:
                Y = A;
                fc++;
                break;
            case 0x9A:
                A = Y;
                fc++;
                break;
            case 0xEA:
                fc++;
                break;
        }
    }
    printf("\n");
    printf("A: %d\n",A);
    printf("X: %d\n",X);
    printf("Y: %d\n",Y);
    printf("SP: %d\n",SP);
    printf("P: %d\n",P);
    //printf("%d\n",zero);
    for (int i = 0; i<65536;i++){
        if (icarus_mem[i] != 0){
            printf("Memory Slot %d\n",i);
            printf("Value: %d\n",icarus_mem[i]);
           // printf("\n");
        }   
    }
    return 0;
}
